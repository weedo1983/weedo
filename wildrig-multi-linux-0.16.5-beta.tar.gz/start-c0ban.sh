#!/bin/bash

while true
do
./wildrig-multi --print-full --algo lyra2vc0ban --opencl-threads auto --opencl-launch auto --url stratum+tcp://eu.bsod.pw:2514 --user 8J1i7WJYiTbb92AcRjzfX1Pob6jiN1kJEG --pass c=RYO
sleep 5
done
