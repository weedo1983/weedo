#!/bin/bash

while true
do
./wildrig-multi --print-full --algo x22i --opencl-threads auto --opencl-launch auto --url stratum+tcp://eu.bsod.pw:2460 --user SauLQKggrWaAcFU8BvZCJ2bEHAYb8QdpQY --pass c=SUQA
sleep 5
done
